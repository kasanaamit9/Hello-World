package com.cg.uas.service;

import java.util.List;

import com.cg.uas.beans.ApplicationBean;
import com.cg.uas.beans.LoginBean;
import com.cg.uas.beans.ProgramsOfferedBean;
import com.cg.uas.beans.ProgramsScheduledBean;

public interface IUasService {
	public LoginBean login(String username, String password) ;
	
	public ProgramsOfferedBean addOfferedPrograms(ProgramsOfferedBean bean);
	
	public List<ProgramsOfferedBean> viewAllProgramsOffered();

	public boolean deleteProgramsOffered(String programName);
	
	public ProgramsOfferedBean findByName(String programName);
	
	public int modifyProgram(ProgramsOfferedBean bean);

	public ProgramsScheduledBean addScheduledPrograms(ProgramsScheduledBean bean);

	public List<ProgramsScheduledBean> viewAllProgramsScheduled();

	public boolean deleteProgramsScheduled(int id);

	public List<ProgramsScheduledBean> viewCommenceTime(ProgramsScheduledBean bean);
	
	public List<ProgramsScheduledBean> viewCourse();
	
	public ApplicationBean addApplicant(ApplicationBean application);
	
	public ApplicationBean viewStatus(int id);

	public List<ApplicationBean> getAllApplicants(String scheduledProgramID);


}
