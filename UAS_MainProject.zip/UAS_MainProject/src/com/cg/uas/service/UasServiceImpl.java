package com.cg.uas.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.uas.beans.ApplicationBean;
import com.cg.uas.beans.LoginBean;
import com.cg.uas.beans.ProgramsOfferedBean;
import com.cg.uas.beans.ProgramsScheduledBean;
import com.cg.uas.dao.IUasDao;


@Service
@Transactional
public class UasServiceImpl implements IUasService {

	@Autowired
	IUasDao dao;
	
	
	
	public IUasDao getDao() {
		return dao;
	}



	public void setDao(IUasDao dao) {
		this.dao = dao;
	}



	@Override
	public LoginBean login(String username, String password) {
		
		return dao.login(username, password);
				
	}



	@Override
	public ProgramsOfferedBean addOfferedPrograms(ProgramsOfferedBean bean) {
		return dao.addOfferedPrograms(bean);
	}



	@Override
	public List<ProgramsOfferedBean> viewAllProgramsOffered() {
		return dao.viewAllProgramsOffered();
	}



	@Override
	public boolean deleteProgramsOffered(String programName) {
		
		return dao.deleteProgramsOffered(programName);
	}



	@Override
	public ProgramsOfferedBean findByName(String programName) {
		return dao.findByName(programName);
	}



	@Override
	public int modifyProgram(ProgramsOfferedBean bean) {
		return dao.modifyProgram(bean);
	}



	@Override
	public ProgramsScheduledBean addScheduledPrograms(ProgramsScheduledBean bean) {
		// TODO Auto-generated method stub
		return dao.addScheduledPrograms(bean);
	}



	@Override
	public List<ProgramsScheduledBean> viewAllProgramsScheduled() {
		// TODO Auto-generated method stub
		return dao.viewAllProgramsScheduled();
	}



	@Override
	public boolean deleteProgramsScheduled(int id) {
		// TODO Auto-generated method stub
		return dao.deleteProgramsScheduled(id);
	}



	@Override
	public List<ProgramsScheduledBean> viewCommenceTime(
			ProgramsScheduledBean bean) {
		return dao.viewCommenceTime(bean);
	}

	@Override
	public List<ProgramsScheduledBean> viewCourse() {
		
		return dao.viewCourse();
	}



	@Override
	public ApplicationBean addApplicant(ApplicationBean application) {
		return dao.addApplicant(application);
	}



	@Override
	public ApplicationBean viewStatus(int id) {
		return dao.viewStatus(id);
	}



	@Override
	public List<ApplicationBean> getAllApplicants(String scheduledProgramID) {
		return dao.getAllApplicants(scheduledProgramID);
	}




}
