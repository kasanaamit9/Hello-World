package com.cg.uas.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="programs_scheduled")
public class ProgramsScheduledBean {
  
	@Id
	@Column(name="scheduled_program_id")
	@SequenceGenerator(name="seq1",sequenceName="scheduled_pgm_seq",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq1")
	private int programId;
	

	@Column(name="programName")
	private String programName;

	@Column(name="Location")
	private String location;

	@DateTimeFormat(pattern="dd/MM/yyyy")
	@NotNull(message="Date cannot be empty")
	@Column(name="start_date")
	private Date startDate;
	
	@DateTimeFormat(pattern="dd/MM/yyyy")
	@NotNull(message="Date cannot be empty")
	@Column(name="end_date")
	private Date endDate;
	

	@Column(name="sessions_per_week ")
	private int sessionPerWeek;
	
	public int getProgramId() {
		return programId;
	}
	public void setProgramId(int programId) {
		this.programId = programId;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public int getSessionPerWeek() {
		return sessionPerWeek;
	}
	public void setSessionPerWeek(int sessionPerWeek) {
		this.sessionPerWeek = sessionPerWeek;
	}
	
}