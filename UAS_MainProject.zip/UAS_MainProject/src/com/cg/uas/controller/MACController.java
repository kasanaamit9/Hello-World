package com.cg.uas.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.uas.beans.ApplicationBean;
import com.cg.uas.beans.ProgramsScheduledBean;
import com.cg.uas.service.IUasService;


@Controller
@RequestMapping("/*.mac")
public class MACController {

	@Autowired
	private IUasService service;

	public IUasService getService() {
		return service;
	}

	public void setService(IUasService service) {
		this.service = service;
	}
	
	@RequestMapping("/view")
	public ModelAndView showabout(@RequestParam("programId") String scheduledProgramID) {
		ModelAndView mv=new ModelAndView();
		
		List<ApplicationBean> list= service.getAllApplicants(scheduledProgramID);
		if (!list.isEmpty()){
			mv.addObject("list", list);
			mv.addObject("flag", 1);
			mv.setViewName("macPage");
		}
		else {
			mv.addObject("msg", "No Applicant is Registered for this Program");
			mv.setViewName("macPage");
		}
		
	return mv;	
	}
	
	
	
}
